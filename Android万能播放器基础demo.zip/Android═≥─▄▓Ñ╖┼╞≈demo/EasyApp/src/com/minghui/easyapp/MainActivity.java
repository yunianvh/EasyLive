package com.minghui.easyapp;

import io.vov.vitamio.MediaPlayer;
import io.vov.vitamio.Vitamio;
import io.vov.vitamio.widget.MediaController;
import io.vov.vitamio.widget.VideoView;
import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
	VideoView mVideoView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Vitamio.isInitialized(getApplicationContext());
		setContentView(R.layout.activity_main);
		mVideoView = (VideoView) findViewById(R.id.surface_view);
		// path="/sdcard/out.ts";
		playfunction("http://222.88.75.168:18299/video/%E7%8A%AC%E4%B9%8B%E5%B2%9B.mp4");
	}

	/**
	 * 开始播放
	 * 
	 * @param path
	 */
	void playfunction(String path) {
		if (path == "") {
			// Tell the user to provide a media file URL/path.
			Toast.makeText(MainActivity.this, "播放地址不能为空", Toast.LENGTH_LONG)
					.show();
			return;
		} else {
			/*
			 * Alternatively,for streaming media you can use
			 * mVideoView.setVideoURI(Uri.parse(URLstring));
			 */
			mVideoView.stopPlayback();
			mVideoView.setVideoPath(path);
			mVideoView.setMediaController(new MediaController(this));
			mVideoView.requestFocus();

			mVideoView
					.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
						@Override
						public void onPrepared(MediaPlayer mediaPlayer) {
							// optional need Vitamio 4.0
							mediaPlayer.setPlaybackSpeed(1.0f);
						}
					});
		}
	}

}
