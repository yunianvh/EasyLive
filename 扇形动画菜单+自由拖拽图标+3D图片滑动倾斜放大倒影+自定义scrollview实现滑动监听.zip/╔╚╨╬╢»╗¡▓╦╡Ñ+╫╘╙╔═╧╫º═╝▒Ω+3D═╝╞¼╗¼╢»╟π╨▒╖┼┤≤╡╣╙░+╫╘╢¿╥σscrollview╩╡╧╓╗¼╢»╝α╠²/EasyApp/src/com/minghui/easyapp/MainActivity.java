package com.minghui.easyapp;

import java.io.File;

import com.minghui.easyapp.camera.DrawOnTop;
import com.minghui.easyapp.camera.Preview;
import com.minghui.easyapp.customgallery.GalleryFlow;
import com.minghui.easyapp.customgallery.ImageAdapter;
import com.minghui.easyapp.dragview.DragView;
import com.minghui.easyapp.scrollview.ObserveScrollView;
import com.minghui.easyapp.scrollview.ObserveScrollView.ScrollListener;
import com.minghui.easyapp.utils.DownLoadManager;
import com.minghui.easyapp.utils.NvaAnimator;

import io.vov.vitamio.MediaPlayer;
import io.vov.vitamio.Vitamio;
import io.vov.vitamio.widget.MediaController;
import io.vov.vitamio.widget.VideoView;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	static WindowManager wm;
	ObserveScrollView scrollView;
	TextView txt;
	RelativeLayout Layout_top;
	VideoView mVideoView;
	Preview mPreview;
	DrawOnTop mDrawOnTop;
	DragView dragView;
	ImageView nva1, nva2, nva3, nva4;
	// TV item
	GridLayout tvLayout;
	ImageView lc1, lc2, lc3, lc4, lc5;
	DragView tvDragView;
	ImageView tvNva1, tvNva2, tvNva3;
	// item
	ImageView item1, item2;
	// GalleryFlow
	GalleryFlow galleryFlow;
	int[] images = { R.drawable.err, R.drawable.err, R.drawable.err,
			R.drawable.err, R.drawable.err, R.drawable.err, R.drawable.err,
			R.drawable.err, };
	// web
	WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Vitamio.isInitialized(getApplicationContext());
		setContentView(R.layout.activity_main);
		wm = this.getWindowManager();
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		init();

		// path="/sdcard/out.ts";
		playfunction("http://222.88.75.168:18299/video/%E7%8A%AC%E4%B9%8B%E5%B2%9B.mp4");
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	/**
	 * 获取屏幕宽
	 * 
	 * @return
	 */
	public static int getWidth() {
		return wm.getDefaultDisplay().getWidth();
	}

	/**
	 * 获取屏幕高
	 * 
	 * @return
	 */
	public static int getHeight() {
		return wm.getDefaultDisplay().getHeight();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
			// 当前为横屏， 在此处添加额外的处理代码
			ViewParams();
		} else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
			// 当前为竖屏， 在此处添加额外的处理代码
			ViewParams();
		}
		super.onConfigurationChanged(newConfig);
	}

	public void init() {
		// 背景滑动
		scrollView = (ObserveScrollView) findViewById(R.id.scrollview);
		txt = (TextView) findViewById(R.id.tv);
		dragView = (DragView) findViewById(R.id.nva_drag);
		nva1 = (ImageView) findViewById(R.id.nva_1);
		nva2 = (ImageView) findViewById(R.id.nva_2);
		nva3 = (ImageView) findViewById(R.id.nva_3);
		nva4 = (ImageView) findViewById(R.id.nva_4);
		// 摄像头、播放器
		Layout_top = (RelativeLayout) findViewById(R.id.Layout_top);
		Layout_top.getLayoutParams().height = getHeight() / 3;
		mDrawOnTop = new DrawOnTop(this);
		mPreview = new Preview(this, mDrawOnTop);
		Layout_top.addView(mPreview);
		// 播放器
		mVideoView = (VideoView) findViewById(R.id.surface_view);
		// TV
		tvLayout = (GridLayout) findViewById(R.id.item_tv_gridLayout);
		lc1 = (ImageView) findViewById(R.id.tv_launcher_1);
		lc2 = (ImageView) findViewById(R.id.tv_launcher_2);
		lc3 = (ImageView) findViewById(R.id.tv_launcher_3);
		lc4 = (ImageView) findViewById(R.id.tv_launcher_4);
		lc5 = (ImageView) findViewById(R.id.tv_launcher_5);
		// TV菜单
		tvDragView = (DragView) findViewById(R.id.tv_nva_drag);
		tvNva1 = (ImageView) findViewById(R.id.tv_nva_1);
		tvNva2 = (ImageView) findViewById(R.id.tv_nva_2);
		tvNva3 = (ImageView) findViewById(R.id.tv_nva_3);
		// item
		item1 = (ImageView) findViewById(R.id.item_img_1);
		item2 = (ImageView) findViewById(R.id.item_img_2);
		ViewParams();
		// GalleryFlow
		galleryFlow = (GalleryFlow) findViewById(R.id.gallery_flow);
		galleryFlow.getLayoutParams().height = getHeight() / 3 - 30;
		ImageAdapter adapter = new ImageAdapter(this, images);
		adapter.createReflectedImages();
		galleryFlow.setAdapter(adapter);
		// web
		// webView = (WebView) findViewById(R.id.item_web);
		// webView.getLayoutParams().height = getHeight() / 3 - 30;
		// WebViewInit();
		// 滑动设置监听
		scrollView.setScrollListener(scrollListener);
		tvDragView.setOnClickListener(this);
		dragView.setOnClickListener(this);
	}

	/**
	 * 滑动数据接收监听，在这里实现你的功能
	 */
	ScrollListener scrollListener = new ScrollListener() {

		@Override
		public void scrollOritention(int l, int t, int oldl, int oldt) {
			// TODO Auto-generated method stub
			txt.setText("l=" + l + "\nt=" + t + "\noldl" + oldl + "\noldt"
					+ oldt);
			// 根据滑动位置来慢慢隐藏广告位置
			if ((getHeight() / 3) - (t / 2) < 0) {
				Layout_top.setVisibility(View.GONE);
			} else {
				if (Layout_top.getVisibility() == View.GONE)
					Layout_top.setVisibility(View.VISIBLE);
				Layout_top.getLayoutParams().height = (getHeight() / 3)
						- (t / 2);
			}
		}
	};

	/**
	 * 开始播放
	 * 
	 * @param path
	 */
	void playfunction(String path) {
		if (path == "") {
			// Tell the user to provide a media file URL/path.
			Toast.makeText(MainActivity.this, "播放地址不能为空", Toast.LENGTH_LONG)
					.show();
			return;
		} else {
			/*
			 * Alternatively,for streaming media you can use
			 * mVideoView.setVideoURI(Uri.parse(URLstring));
			 */
			mVideoView.stopPlayback();
			mVideoView.setVideoPath(path);
			mVideoView.setMediaController(new MediaController(this));
			mVideoView.requestFocus();

			mVideoView
					.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
						@Override
						public void onPrepared(MediaPlayer mediaPlayer) {
							// optional need Vitamio 4.0
							mediaPlayer.setPlaybackSpeed(1.0f);
						}
					});
		}
	}

	/**
	 * ------------------------------------------------------------------------
	 * --------------------- TVlauncher处理 -------------------------------------
	 * -----------------设置tv模块launcher的位置大小---------------------------------
	 */
	public void ViewParams() {
		lc1.getLayoutParams().width = getWidth() / 2 - 30;
		lc1.getLayoutParams().height = (getHeight() / 3 - 30) / 2;
		lc2.getLayoutParams().width = getWidth() / 4 - 30;
		lc2.getLayoutParams().height = (getHeight() / 3 - 30) / 2;
		lc3.getLayoutParams().width = getWidth() / 4 - 30;
		lc3.getLayoutParams().height = getHeight() / 3 - 30;
		lc4.getLayoutParams().width = getWidth() / 4 - 30;
		lc4.getLayoutParams().height = (getHeight() / 3 - 30) / 2;
		lc5.getLayoutParams().width = getWidth() / 2 - 30;
		lc5.getLayoutParams().height = (getHeight() / 3 - 30) / 2;
		// item
		item1.getLayoutParams().height = (getHeight() / 3 - 30) / 2 + 5;
		item2.getLayoutParams().height = (getHeight() / 3 - 30) / 2 + 5;
	}

	boolean isShowTvNva = true;

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.tv_nva_drag:
			if (isShowTvNva) {
				isShowTvNva = false;
				NvaAnimator.openAnim(tvNva1, 4, 5, 150, true);
				NvaAnimator.openAnim(tvNva2, 5, 5, 150, true);
				NvaAnimator.openAnim(tvNva3, 6, 5, 150, true);
			} else {
				isShowTvNva = true;
				NvaAnimator.closeAnim(tvNva1, 4, 5, 150, true);
				NvaAnimator.closeAnim(tvNva2, 5, 5, 150, true);
				NvaAnimator.closeAnim(tvNva3, 6, 5, 150, true);
			}
			break;
		case R.id.nva_drag:
			if (isShowTvNva) {
				isShowTvNva = false;
				NvaAnimator.openAnim(nva1, 1, 5, 150, false);
				NvaAnimator.openAnim(nva2, 2, 5, 150, false);
				NvaAnimator.openAnim(nva3, 3, 5, 150, false);
				NvaAnimator.openAnim(nva4, 4, 5, 150, false);
			} else {
				isShowTvNva = true;
				NvaAnimator.closeAnim(nva1, 1, 5, 150, false);
				NvaAnimator.closeAnim(nva2, 2, 5, 150, false);
				NvaAnimator.closeAnim(nva3, 3, 5, 150, false);
				NvaAnimator.closeAnim(nva4, 4, 5, 150, false);
			}
			break;

		default:
			break;
		}
	}

	/**
	 * ------------------------------------------------------------------------
	 * -----------------------WebView处理---------------------------------------
	 */
	@SuppressLint("SetJavaScriptEnabled")
	public void WebViewInit() {
		webView.setDownloadListener(new MyWebViewDownLoadListener());
		webView.setWebViewClient(new WebViewClient());
		WebSettings webSettings = webView.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setBuiltInZoomControls(true); // 设置显示缩放按钮
		webSettings.setSupportZoom(true);
		webSettings.setUseWideViewPort(true);
		webSettings.setLoadWithOverviewMode(true);
		WebLoad("http://www.augesion.com/");
	}

	/**
	 * webview加载
	 * 
	 * @param url
	 */

	public void WebLoad(String url) {
		// TODO Auto-generated method stub
		webView.loadUrl(url);
	}

	/**
	 * 下载
	 * 
	 * @author Administrator
	 */
	private class MyWebViewDownLoadListener implements DownloadListener {

		@Override
		public void onDownloadStart(String url, String userAgent,
				String contentDisposition, String mimetype, long contentLength) {
			downLoadApk(url);
		}
	}

	/**
	 * 更新进度
	 */
	protected void downLoadApk(final String url) {
		final ProgressDialog pd; //
		pd = new ProgressDialog(this);
		pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		pd.setMessage("更新进度");
		pd.show();
		new Thread() {
			@Override
			public void run() {
				try {
					File file = DownLoadManager.getFileFromServer(url, pd);
					sleep(3000);
					installApk(file);
					pd.dismiss();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
	}

	/**
	 * apk安装
	 * 
	 * @param file
	 */
	protected void installApk(File file) {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(file),
				"application/vnd.android.package-archive");
		startActivity(intent);
		finish();
	}
}
