/*
 * Copyright (C) 2012-2016 YunBo(ShenZhen) Co.,Ltd. All right reserved.
 * @version V1.0  
 */
package com.minghui.easyapp.utils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URL;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

public class Func {

	// private static final int CORES =
	// Runtime.getRuntime().availableProcessors();
	// private static final int POOL_SIZE = CORES + 1;
	// private static final int POOL_SIZE_MAX = CORES * 2 + 1;
	private static final BlockingQueue<Runnable> POOL_QUEUE_TASK = new SynchronousQueue<Runnable>();
	private static final ThreadFactory TASK_FACTORY = new ThreadFactory() {
		private final AtomicInteger COUNT = new AtomicInteger(1);

		public Thread newThread(Runnable runnable) {
			int count = COUNT.getAndIncrement();
			return new Thread(runnable, "Func #" + count);
		}
	};
	public static final ExecutorService FUNC_TASK = new ThreadPoolExecutor(0,
			Integer.MAX_VALUE, 3L, TimeUnit.SECONDS, POOL_QUEUE_TASK,
			TASK_FACTORY);

	@SuppressWarnings("deprecation")
	public static HttpURLConnection getHttpURLConnection(String urlString) {
		if (TextUtils.isEmpty(urlString)) {
			return null;
		}
		try {
			URL url = new URL(urlString);
			HttpURLConnection httpURLConnection = null;
			if (TextUtils.isEmpty(android.net.Proxy.getDefaultHost())) {
				httpURLConnection = (HttpURLConnection) url.openConnection();
			} else {
				if (urlString.startsWith("http://127.0.0.1")) {
					Log.e("getHttpURLConnection", "http://127.0.0.1");
					httpURLConnection = (HttpURLConnection) url
							.openConnection(java.net.Proxy.NO_PROXY);
				} else {
					httpURLConnection = (HttpURLConnection) url
							.openConnection(new Proxy(Type.HTTP,
									new InetSocketAddress(android.net.Proxy
											.getDefaultHost(),
											android.net.Proxy.getDefaultPort())));
				}
			}
			httpURLConnection.setConnectTimeout(3000);
			httpURLConnection.setReadTimeout(3000);
			return httpURLConnection;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static String postImplRequest(Context context, String urlString,
			String postParam) {
		try {
			HttpURLConnection hc = getHttpURLConnection(urlString);
			if (hc == null) {
				return null;
			}
			hc.setDoOutput(true);
			hc.setDoInput(true);
			hc.setUseCaches(false);
			hc.setRequestMethod("POST");
			hc.setRequestProperty("Content-Type", "application/octet-stream");
			LogUtils.e(postParam);
			byte[] bits = postParam.getBytes("UTF-8");
			if (bits != null) {
				hc.setRequestProperty("Content-Length", bits.length + "");
			}
			OutputStream out = hc.getOutputStream();
			if (bits != null) {
				out.write(bits);
				out.flush();
			}
			InputStream input = hc.getInputStream();
			ByteArrayOutputStream byteArr = new ByteArrayOutputStream();
			byte[] bytes = new byte[1024];
			int k = 0;
			while ((k = input.read(bytes)) != -1) {
				byteArr.write(bytes, 0, k);
			}
			byteArr.flush();
			byte[] returnDatas = byteArr.toByteArray();
			byteArr.close();
			input.close();
			out.close();
			String result = new String(returnDatas, "UTF-8");
			FileUtils.writeFile(
					String.format(Constants.SEATINFOS_FILE_PATH,
							context.getApplicationInfo().packageName), result);
			return result;
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonIOException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (JsonSyntaxException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (JsonParseException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 韩国版请求
	 */
	public static String postRequest(Context context, String urlString,
			String postParam, String filePath) {
		try {
			HttpURLConnection hc = getHttpURLConnection(urlString);
			if (hc == null) {
				return null;
			}
			hc.setDoOutput(true);
			hc.setDoInput(true);
			hc.setUseCaches(false);
			hc.setRequestMethod("POST");
			hc.setRequestProperty("Content-Type", "application/octet-stream");

			LogUtils.e(postParam);
			byte[] bits = postParam.getBytes("UTF-8");
			if (bits != null) {
				hc.setRequestProperty("Content-Length", bits.length + "");
			}
			OutputStream out = hc.getOutputStream();
			if (bits != null) {
				out.write(bits);
				out.flush();
			}
			InputStream input = hc.getInputStream();
			ByteArrayOutputStream byteArr = new ByteArrayOutputStream();
			byte[] bytes = new byte[1024];
			int k = 0;
			while ((k = input.read(bytes)) != -1) {
				byteArr.write(bytes, 0, k);
			}
			byteArr.flush();
			byte[] returnDatas = byteArr.toByteArray();
			byteArr.close();
			input.close();
			out.close();
			String result = new String(returnDatas, "UTF-8");
			FileUtils.writeFile(String.format(filePath,
					context.getApplicationInfo().packageName), result);
			return result;
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonIOException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (JsonSyntaxException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (JsonParseException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * add by wu 180516 -----------------------------------------
	 * 
	 * @param implString
	 * @return
	 */
	// public static HotleInfo parseImplHotleInfo(String implString) {
	// HotleInfo hotleInfo = null;
	// try {
	// Gson gson = new Gson();
	// hotleInfo = gson.fromJson(implString, HotleInfo.class);
	// } catch (JsonIOException e) {
	// // TODO: handle exception
	// e.printStackTrace();
	// } catch (JsonSyntaxException e) {
	// // TODO: handle exception
	// e.printStackTrace();
	// } catch (JsonParseException e) {
	// // TODO: handle exception
	// e.printStackTrace();
	// }
	// return hotleInfo;
	// }

	public static boolean deleteDir(File dir) {
		if (dir != null && dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		return dir.delete();
	}

	public static String getVideoPath(Context context, String url, String dir) {
		File videoCache = FileUtils.getDiskCacheDir(context, dir);
		if (!videoCache.exists()) {
			videoCache.mkdirs();
		}
		File file = new File(videoCache, MD5Utils.md5Str(url));// +url.substring(url.lastIndexOf("."))
		File tmpFile = new File(videoCache, MD5Utils.md5Str(url) + ".tmp");
		String path = null;
		boolean download = false;
		long offset = 0;
		if (file.exists()) {
			path = file.getAbsolutePath();
			return path;
		} else if (tmpFile.exists()) {
			offset = tmpFile.length();
			download = downLoad(context, url, file, tmpFile, offset);
		} else {
			deleteDir(videoCache);
			File videoCache2 = FileUtils.getDiskCacheDir(context, dir);
			if (!videoCache2.exists()) {
				videoCache2.mkdirs();
			}
			File file2 = new File(videoCache2, MD5Utils.md5Str(url));// +url.substring(url.lastIndexOf("."))
			File tmpFile2 = new File(videoCache2, MD5Utils.md5Str(url) + ".tmp");
			download = downLoad(context, url, file2, tmpFile2, offset);
		}
		if (download) {
			path = file.getAbsolutePath();
		}
		return path;
	}

	public static boolean downLoad(Context context, String url, File file,
			File tmpFile, long offset) {
		HttpURLConnection connection = getHttpURLConnection(url);
		try {
			connection.setRequestMethod("GET");
			connection.setRequestProperty("RANGE", "bytes=" + offset + "-");
			RandomAccessFile randomAccess = null;
			if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
				randomAccess = getRandomAccessFile(tmpFile, 0);
			} else if (connection.getResponseCode() == HttpURLConnection.HTTP_PARTIAL) {
				randomAccess = getRandomAccessFile(tmpFile, offset);
			}
			// Log.e("ddddddddddddddddd", "" + connection.getResponseCode());
			InputStream inputStream = connection.getInputStream();
			byte[] buffer = new byte[1024 * 8];
			int len = -1;
			while ((len = inputStream.read(buffer)) != -1) {
				randomAccess.write(buffer, 0, len);
			}
			randomAccess.close();
			tmpFile.renameTo(file);
			return true;
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public static RandomAccessFile getRandomAccessFile(File file, long offset)
			throws IOException {
		RandomAccessFile raf = new RandomAccessFile(file, "rwd");
		raf.seek(offset);
		return raf;
	}

	@SuppressLint("DefaultLocale")
	public static String getMac() {
		String macString = "";
		try {
			InputStream localInputStream = Runtime.getRuntime()
					.exec("cat /sys/class/net/eth0/address").getInputStream();
			InputStreamReader localInputStreamReader = new InputStreamReader(
					localInputStream);
			BufferedReader localBufferedReader = new BufferedReader(
					localInputStreamReader);
			String str2 = localBufferedReader.readLine();
			if (str2 != null) {
				macString = str2;
				Log.i("test", "str2==" + str2);
			}
			localBufferedReader.close();
			localInputStreamReader.close();
			localInputStream.close();
			String str3 = ((String) macString).toUpperCase();
			if (str3 == null || str3.equals("")) {
				macString = "unAugesionBox";
			} else {
				macString = str3;
			}
		} catch (IOException localIOException) {
			localIOException.printStackTrace();
			macString = "unAugesionBox";
		}
		return macString;
	}

	/**
	 * 创建指定数量的随机字符串
	 * 
	 * @param numberFlag
	 *            是否是数字
	 * @param length
	 * @return
	 */
	public static String createRandom(boolean numberFlag, int length) {
		String retStr = "";
		String strTable = numberFlag ? "1234567890"
				: "1234567890abcdefghijkmnpqrstuvwxyz";
		int len = strTable.length();
		boolean bDone = true;
		do {
			retStr = "";
			int count = 0;
			for (int i = 0; i < length; i++) {
				double dblR = Math.random() * len;
				int intR = (int) Math.floor(dblR);
				char c = strTable.charAt(intR);
				if (('0' <= c) && (c <= '9')) {
					count++;
				}
				retStr += strTable.charAt(intR);
			}
			if (count >= 2) {
				bDone = false;
			}
		} while (bDone);
		Log.i("test", "3mac:" + retStr);
		return retStr;
	}

	/**
	 * 从网络端下载图片 add by wu 180517---------------------------------------
	 * 
	 * @param url
	 *            网络图片的URL地址
	 * @return bitmap 图片bitmap结构
	 * 
	 */
	public static Bitmap getBitmapFromUrl(String url) {
		Bitmap bitmap = null;
		try {
			URL u = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) u.openConnection();
			InputStream is = conn.getInputStream();
			bitmap = BitmapFactory.decodeStream(is);
			is.close();
			conn.disconnect();
			return bitmap;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
