/**
 * 感谢洒家卖蘑菇
 * 博客地址：https://blog.csdn.net/qq_36510659/article/details/78834302
 */
package com.minghui.easyapp.utils;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.animation.BounceInterpolator;

public class NvaAnimator {
	/**
	 * 打开菜单 view:动画控件 index：第几个控件 num:有几个控件 radius：扇形半径
	 */
	public static void openAnim(View view, int index, int num, int radius,
			boolean isRadians) {
		if (view.getVisibility() != View.VISIBLE) {
			view.setVisibility(View.VISIBLE);
		}
		final int translationX;
		final int translationY;
		if (isRadians) {
			double angle = Math.toRadians(180) / (num - 1) * index;
			translationX = -(int) (radius * Math.cos(angle));
			translationY = -(int) (radius * Math.sin(angle));
		} else {
			translationX = index * 80 + 20 * index;
			translationY = 0;
		}
		ObjectAnimator one = ObjectAnimator.ofFloat(view, "translationX", 0,
				translationX);
		ObjectAnimator two = ObjectAnimator.ofFloat(view, "translationY", 0,
				translationY);
		ObjectAnimator three = ObjectAnimator.ofFloat(view, "rotation", 0, 360);
		ObjectAnimator four = ObjectAnimator.ofFloat(view, "scaleX", 0f, 1f);
		ObjectAnimator five = ObjectAnimator.ofFloat(view, "scaleY", 0f, 1f);
		ObjectAnimator six = ObjectAnimator.ofFloat(view, "alpha", 0f, 1);
		AnimatorSet set = new AnimatorSet();
		if (isRadians) {
			set.playTogether(one, two, three, four, five, six);
		} else {
			set.playTogether(one, two, six);
		}
		set.setDuration(2000);
		// 回弹效果
		set.setInterpolator(new BounceInterpolator());
		set.start();
	}

	/**
	 * 关闭扇形菜单
	 * 
	 * @param view
	 * @param index
	 * @param num
	 * @param radius
	 */
	public static void closeAnim(View view, int index, int num, int radius,
			boolean isRadians) {
		if (view.getVisibility() != View.VISIBLE) {
			view.setVisibility(View.VISIBLE);
		}
		final int translationX;
		final int translationY;
		if (isRadians) {
			double angle = Math.toRadians(180) / (num - 1) * index;
			translationX = -(int) (radius * Math.cos(angle));
			translationY = -(int) (radius * Math.sin(angle));
		} else {
			translationX = index * 80 + 20 * index;
			translationY = 0;
		}
		ObjectAnimator one = ObjectAnimator.ofFloat(view, "translationX",
				translationX, 0);
		ObjectAnimator two = ObjectAnimator.ofFloat(view, "translationY",
				translationY, 0);
		ObjectAnimator three = ObjectAnimator.ofFloat(view, "rotation", 0, 360);
		ObjectAnimator four = ObjectAnimator.ofFloat(view, "scaleX", 1f, 0f);
		ObjectAnimator five = ObjectAnimator.ofFloat(view, "scaleY", 1f, 0f);
		ObjectAnimator six = ObjectAnimator.ofFloat(view, "alpha", 1f, 0f);

		AnimatorSet set = new AnimatorSet();
		if (isRadians) {
			set.playTogether(one, two, three, four, five, six);
		} else {
			set.playTogether(one, two, six);
		}
		set.setDuration(2000);
		// 回弹效果
		set.setInterpolator(new BounceInterpolator());
		set.start();
	}
}
