package com.minghui.easyapp.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.content.Context;
import android.os.Environment;

public class PlayHistoryUtils {

	public static String SAVE_PATH = Environment.getExternalStorageDirectory()
			.getAbsolutePath() + "/download/";
	public static File endfile;

	public static void SaveVDInfo(Context context, String vdName, String vdImg,
			String vdUrl) {
		File file = checkLogFileIsExist();
		String data = "{\"vdname\":\"" + vdName + "\",\"vdimg\":\"" + vdImg
				+ "\",\"vdurl\":\"" + vdUrl + "\"},";
		if (file == null)
			return;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file, true);
			fos.write(data.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
			}
			fos = null;
			file = null;
		}
	}

	/** 检查文件是否存在 */
	public static File checkLogFileIsExist() {
		endfile = new File(SAVE_PATH);
		if (!endfile.exists()) {
			endfile.mkdirs();
		}
		endfile = new File(SAVE_PATH + "playHistory.txt");
		if (endfile.exists()) {
			long fileSize = endfile.length();
			long maxLogFileSize = 100 * 100;// 最大不能超过100 * 100
			if (fileSize > maxLogFileSize) {
				endfile.delete();// 如果大于就删除文件
			} else {
				return endfile;
			}
		} else {
			try {
				endfile.createNewFile();
			} catch (IOException e) {
			}
		}
		return endfile;
	}

	public static void deleteFile() {
		endfile = new File(SAVE_PATH);
		if (endfile.exists()) {
			endfile.delete();// 就删除文件
		}
	}
}
