/*
 * Copyright (C) 2012-2016 YunBo(ShenZhen) Co.,Ltd. All right reserved.
 * @version V1.0  
 */
package com.minghui.easyapp.utils;

import android.annotation.SuppressLint;
import android.os.Environment;

public class Constants {
	/**
	 * @Fields SEATINFOS_FILE_PATH : 坑位信息保存路径
	 */
	@SuppressLint("SdCardPath")
	public static final String SEATINFOS_FILE_PATH = "/data/data/%s/files/seatinfos.json";
	public static final String POSTONCLICK_PATH = "http://www.trehere.com:8787/ajx/service/data?type=clickseat";
	public static String SEATINFOS_AGENCY_PATH = Environment
			.getExternalStorageDirectory().getAbsolutePath()
			+ "/download/sys/agency.txt";
	/**
	 * 韩国版
	 */
	@SuppressLint("SdCardPath")
	public static final String ZHIBO_FILE_PATH = "/data/data/%s/files/zhibo.json";
	@SuppressLint("SdCardPath")
	public static final String ZHIBOTYPE_FILE_PATH = "/data/data/%s/files/zhibotype.json";

	@SuppressLint("SdCardPath")
	public static final String DIANBO_FILE_PATH = "/data/data/%s/files/dianbo.json";
	@SuppressLint("SdCardPath")
	public static final String DIANBOITEM_FILE_PATH = "/data/data/%s/files/dianboitem.json";
	@SuppressLint("SdCardPath")
	public static final String DIANBOBIGTYPE_FILE_PATH = "/data/data/%s/files/dianbobigtype.json";
	@SuppressLint("SdCardPath")
	public static final String DIANBOMIDTYPE_FILE_PATH = "/data/data/%s/files/dianbomidtype.json";
}
