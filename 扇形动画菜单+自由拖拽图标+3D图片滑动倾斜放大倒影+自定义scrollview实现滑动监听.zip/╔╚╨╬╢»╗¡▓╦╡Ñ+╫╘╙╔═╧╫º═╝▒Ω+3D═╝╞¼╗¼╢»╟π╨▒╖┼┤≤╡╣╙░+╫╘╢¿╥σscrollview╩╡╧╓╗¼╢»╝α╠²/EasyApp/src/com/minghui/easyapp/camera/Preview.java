/**
 * 感谢 郑海波 调用摄像头的文章
 * CSDN:blog.csdn.net/nuptboyzhb
 * 修改By吴明辉，根据横竖屏自动调节preview方向
 * CSDN:https://me.csdn.net/qq_35350654
 */
package com.minghui.easyapp.camera;

import java.io.IOException;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.hardware.Camera.PreviewCallback;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

@TargetApi(9)
public class Preview extends SurfaceView implements SurfaceHolder.Callback {
	SurfaceHolder mHolder;
	Camera mCamera;
	DrawOnTop mDrawOnTop;
	boolean mFinished;
	Context context;
	int CammeraIndex;// 摄像头方向

	public Preview(Context context, DrawOnTop drawOnTop) {
		super(context);
		this.context = context;
		mDrawOnTop = drawOnTop;
		mFinished = false;

		// Install a SurfaceHolder.Callback so we get notified when the
		// underlying surface is created and destroyed.
		mHolder = getHolder();
		mHolder.addCallback(this);
		mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	}

	@TargetApi(9)
	private int FindFrontCamera() {
		int cameraCount = 0;
		Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
		cameraCount = Camera.getNumberOfCameras(); // get cameras number

		for (int camIdx = 0; camIdx < cameraCount; camIdx++) {
			Camera.getCameraInfo(camIdx, cameraInfo); // get camerainfo
			if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) { // ��������ͷ�ķ�λ��Ŀǰ�ж���ֵ�����ֱ�ΪCAMERA_FACING_FRONTǰ�ú�CAMERA_FACING_BACK����
				return camIdx;
			}
		}
		return -1;
	}

	@TargetApi(9)
	private int FindBackCamera() {
		int cameraCount = 0;
		Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
		cameraCount = Camera.getNumberOfCameras(); // get cameras number

		for (int camIdx = 0; camIdx < cameraCount; camIdx++) {
			Camera.getCameraInfo(camIdx, cameraInfo); // get camerainfo
			if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) { // ��������ͷ�ķ�λ��Ŀǰ�ж���ֵ�����ֱ�ΪCAMERA_FACING_FRONTǰ�ú�CAMERA_FACING_BACK����
				return camIdx;
			}
		}
		return -1;
	}

	public void surfaceCreated(SurfaceHolder holder) {
		CammeraIndex = FindBackCamera();
		if (CammeraIndex == -1) {
			CammeraIndex = FindFrontCamera();
		}
		mCamera = Camera.open(CammeraIndex);
		try {
			mCamera.setPreviewDisplay(holder);

			// Preview callback used whenever new viewfinder frame is available
			mCamera.setPreviewCallback(new PreviewCallback() {
				public void onPreviewFrame(byte[] data, Camera camera) {
					if ((mDrawOnTop == null) || mFinished)
						return;

					if (mDrawOnTop.mBitmap == null) {
						// Initialize the draw-on-top companion
						Camera.Parameters params = camera.getParameters();
						mDrawOnTop.mImageWidth = params.getPreviewSize().width;
						mDrawOnTop.mImageHeight = params.getPreviewSize().height;
						mDrawOnTop.mBitmap = Bitmap.createBitmap(
								mDrawOnTop.mImageWidth,
								mDrawOnTop.mImageHeight, Bitmap.Config.RGB_565);
						mDrawOnTop.mRGBData = new int[mDrawOnTop.mImageWidth
								* mDrawOnTop.mImageHeight];
						mDrawOnTop.mYUVData = new byte[data.length];
					}

					// Pass YUV data to draw-on-top companion
					System.arraycopy(data, 0, mDrawOnTop.mYUVData, 0,
							data.length);
					mDrawOnTop.invalidate();
				}
			});

			// Define on touch listener
			this.setOnTouchListener(new OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					if (mDrawOnTop.mState == DrawOnTop.STATE_ORIGINAL) {
						mDrawOnTop.mState = DrawOnTop.STATE_PROCESSED;
					} else if (mDrawOnTop.mState == DrawOnTop.STATE_PROCESSED) {
						mDrawOnTop.mState = DrawOnTop.STATE_ORIGINAL;
					}
					return false;
				}
			});
		} catch (IOException exception) {
			mCamera.release();
			mCamera = null;
		}
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		// Surface will be destroyed when we return, so stop the preview.
		// Because the CameraDevice object is not a shared resource, it's very
		// important to release it when the activity is paused.
		mFinished = true;
		mCamera.setPreviewCallback(null);
		mCamera.stopPreview();
		mCamera.release();
		mCamera = null;
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		try {
			mCamera.setPreviewDisplay(holder);
			mCamera.startPreview();
			setCameraDisplayOrientation((Activity) context, CammeraIndex,
					mCamera);
		} catch (Exception e) {
		}
	}

	/**
	 * 根据横竖屏自动调节preview方向，Starting from API level 14, this method can be called
	 * when preview is active.
	 * 
	 * @param activity
	 * @param cameraId
	 * @param camera
	 */
	public static void setCameraDisplayOrientation(Activity activity,
			int cameraId, Camera camera) {
		Camera.CameraInfo info = new Camera.CameraInfo();
		Camera.getCameraInfo(cameraId, info);
		int rotation = activity.getWindowManager().getDefaultDisplay()
				.getRotation();

		// degrees the angle that the picture will be rotated clockwise. Valid
		// values are 0, 90, 180, and 270.
		// The starting position is 0 (landscape).
		int degrees = 0;
		switch (rotation) {
		case Surface.ROTATION_0:
			degrees = 0;
			break;
		case Surface.ROTATION_90:
			degrees = 90;
			break;
		case Surface.ROTATION_180:
			degrees = 180;
			break;
		case Surface.ROTATION_270:
			degrees = 270;
			break;
		}
		int result;
		if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
			result = (info.orientation + degrees) % 360;
			result = (360 - result) % 360; // compensate the mirror
		} else {
			// back-facing
			result = (info.orientation - degrees + 360) % 360;
		}
		camera.setDisplayOrientation(result);
	}
}